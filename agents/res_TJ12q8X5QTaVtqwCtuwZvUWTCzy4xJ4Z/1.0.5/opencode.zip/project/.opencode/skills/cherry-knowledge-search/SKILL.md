---
name: cherry-knowledge-search
description: Cherry Studio knowledge base retrieval. Use when the user asks to search, query, retrieve, or cite Cherry Studio knowledge bases, including Chinese requests such as 检索知识库, 查询知识库, 知识库搜索, or 从知识库查资料.
---

# Cherry Knowledge Search

Use this skill to retrieve information from Cherry Studio knowledge bases through the local Cherry Studio API.

## Workflow

1. Read `config.json` from this skill directory.
2. If `auth.api_key` is empty, ask the user for the Cherry Studio API key before querying.
3. If `knowledge_base_ids` is empty, search all knowledge bases. If it is non-empty, only search those IDs unless the user explicitly asks for another knowledge base.
4. Use `scripts/cherry_knowledge.py search "<query>"` for retrieval.
5. Answer from the returned chunks. Include source metadata when available, especially `knowledge_base_name`, `score`, `metadata.source`, and file/page fields.

## Commands

List configured knowledge bases:

```powershell
python "C:\Users\huaqi\.config\opencode\skills\cherry-knowledge-search\scripts\cherry_knowledge.py" list
```

Get one knowledge base by ID:

```powershell
python "C:\Users\huaqi\.config\opencode\skills\cherry-knowledge-search\scripts\cherry_knowledge.py" get "<knowledge-base-id>"
```

Search knowledge bases:

```powershell
python "C:\Users\huaqi\.config\opencode\skills\cherry-knowledge-search\scripts\cherry_knowledge.py" search "<query>" --count 5
```

Override configured IDs for one search:

```powershell
python "C:\Users\huaqi\.config\opencode\skills\cherry-knowledge-search\scripts\cherry_knowledge.py" search "<query>" --knowledge-base-id "<id-1>" --knowledge-base-id "<id-2>"
```

## API Endpoints

The script wraps these Cherry Studio endpoints:

- `GET /v1/knowledge-bases`: list knowledge bases. Query parameters: `limit`, `offset`.
- `GET /v1/knowledge-bases/{id}`: get a single knowledge base.
- `POST /v1/knowledge-bases/search`: search knowledge bases.

Search request body:

```json
{
  "query": "How do I configure Ollama embedding?",
  "knowledge_base_ids": ["kb-uuid-1", "kb-uuid-2"],
  "document_count": 5
}
```

Authentication uses `Authorization: Bearer <api_key>` when `auth.api_key` is configured.
